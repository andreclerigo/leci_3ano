from django.contrib import admin
from conversation.models import Conversation

# Register your models here.
admin.site.register(Conversation)