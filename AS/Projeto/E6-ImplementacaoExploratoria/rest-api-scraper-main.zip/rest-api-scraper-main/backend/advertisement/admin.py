from django.contrib import admin
from advertisement.models import Advertisement

admin.site.register(Advertisement)
